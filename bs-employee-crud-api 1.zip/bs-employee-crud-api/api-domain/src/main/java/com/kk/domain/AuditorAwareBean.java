package com.kk.domain;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.kk.domain.repo.AccountRepo;

@Service
public class AuditorAwareBean implements AuditorAware<String> {
	
	@Autowired
	private AccountRepo repo;

	@Override
	public Optional<String> getCurrentAuditor() {
		return Optional.ofNullable(SecurityContextHolder.getContext())
				.map(c -> c.getAuthentication())
				.map(a -> a.getName())
				.flatMap(n -> repo.findOneByUsername(n))
				.map(u -> u.getName())
				.or(() -> Optional.of("System"));
	}

}
