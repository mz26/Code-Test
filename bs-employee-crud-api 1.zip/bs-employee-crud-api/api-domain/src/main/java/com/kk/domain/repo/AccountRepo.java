package com.kk.domain.repo;

import java.util.Optional;

import com.kk.domain.BaseRepository;
import com.kk.domain.entity.Account;

public interface AccountRepo extends BaseRepository<Account, Long> {

	Optional<Account> findOneByUsername(String string);

}
