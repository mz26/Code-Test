package com.kk.domain.repo;

import org.springframework.stereotype.Repository;

import com.kk.domain.BaseRepository;
import com.kk.domain.entity.Employee;

@Repository
public interface EmployeeRepo extends BaseRepository<Employee, String> {

}
