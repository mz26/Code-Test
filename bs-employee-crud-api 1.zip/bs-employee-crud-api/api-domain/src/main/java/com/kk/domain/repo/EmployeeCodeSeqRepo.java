package com.kk.domain.repo;

import com.kk.domain.BaseRepository;
import com.kk.domain.entity.EmployeeCodeSeq;

public interface EmployeeCodeSeqRepo extends BaseRepository<EmployeeCodeSeq, String>{

}
