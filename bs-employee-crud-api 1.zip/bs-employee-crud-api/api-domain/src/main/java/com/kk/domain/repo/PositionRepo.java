package com.kk.domain.repo;

import org.springframework.stereotype.Repository;

import com.kk.domain.BaseRepository;
import com.kk.domain.entity.Position;
import com.kk.domain.entity.PositionPk;

@Repository
public interface PositionRepo extends BaseRepository<Position, PositionPk> {

}
