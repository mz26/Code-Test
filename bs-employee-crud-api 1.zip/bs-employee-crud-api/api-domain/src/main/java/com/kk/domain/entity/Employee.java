package com.kk.domain.entity;

import java.time.LocalDate;

import com.kk.domain.BaseEntity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Employee extends BaseEntity {

	@Id
	private String code;

	@OneToOne(optional = false, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private Account account;

	@ManyToOne(optional = false)
	private Department department;

	@ManyToOne(optional = false)
	private Position position;

	@Column(nullable = false)
	private String phone;

	@Column(nullable = false)
	private String email;

	@Column(nullable = false)
	private Gender gender;

	@Column(nullable = false)
	private LocalDate dateOfBirth;

	@Column(nullable = false)
	private Status status;

	@Column(nullable = false, name = "assign_date")
	private LocalDate assignDate;

	private LocalDate probationPassDate;
	private LocalDate retiredDate;

	private String remark;

	public enum Status {
		Probation, Permenant, Retired
	}

	public enum Gender {
		Male, Female
	}

}
