package com.kk.domain.repo;

import org.springframework.stereotype.Repository;

import com.kk.domain.BaseRepository;
import com.kk.domain.entity.Department;

@Repository
public interface DepartmentRepo extends BaseRepository<Department, String> {

	long countByCode(String code);
	
}
