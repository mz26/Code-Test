package com.kk.domain.entity;

import java.math.BigDecimal;
import java.util.List;

import com.kk.domain.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Position extends BaseEntity {

	@EmbeddedId
	private PositionPk id;

	@ManyToOne
	@JoinColumn(name = "department_code", referencedColumnName = "code", insertable = false, updatable = false)
	private Department department;
	
	@OneToMany(mappedBy = "position")
	private List<Employee> employees;

	private List<String> permissions;

	@Column(nullable = false)
	private BigDecimal basicSalary;

	@Column(nullable = false)
	private BigDecimal otFeesPerHour;

	@Column(nullable = false)
	private int anualLeaves;

}
