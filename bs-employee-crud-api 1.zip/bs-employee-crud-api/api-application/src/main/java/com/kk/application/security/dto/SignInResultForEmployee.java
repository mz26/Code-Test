package com.kk.application.security.dto;

import java.time.LocalDate;
import java.util.List;

import com.kk.domain.entity.Employee.Status;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignInResultForEmployee extends SignInResult{

	private String departmentCode;
	private String departmentName;
	private String positionCode;
	private String positionName;
	private Status status;
	private LocalDate assignDate;
	private List<String> permissions;
	
}
