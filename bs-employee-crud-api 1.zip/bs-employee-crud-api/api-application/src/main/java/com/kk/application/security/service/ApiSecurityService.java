package com.kk.application.security.service;

import static com.kk.utils.helpers.EntityOperationHelper.getOne;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kk.application.security.ApiTokenProvider;
import com.kk.application.security.dto.SignInForm;
import com.kk.application.security.dto.SignInResult;
import com.kk.application.security.dto.SignInResultForEmployee;
import com.kk.domain.entity.Account;
import com.kk.domain.entity.Account.Role;
import com.kk.domain.repo.AccountRepo;

@Service
public class ApiSecurityService {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private ApiTokenProvider tokenProvider;

	@Autowired
	private AccountRepo accountRepo;

	@Transactional(readOnly = true)
	public SignInResult signIn(SignInForm form) {

		var authentication = authenticationManager.authenticate(form.authentication());

		var token = tokenProvider.generate(authentication);

		var account = getOne(accountRepo.findOneByUsername(authentication.getName()), "Account",
				authentication.getName());

		return buildResult(account, token);
	}

	private SignInResult buildResult(Account account, String token) {

		if (account.getRole() == Role.Admin) {
			return buildResultForAdmin(account, token);
		}

		return buildREsultForEmployee(account, token);
	}

	private SignInResult buildREsultForEmployee(Account account, String token) {

		var result = new SignInResultForEmployee();

		result.setActivated(account.isActivated());
		result.setAuthorities(List.of(account.getRole().name()));
		result.setLoginId(account.getUsername());
		result.setName(account.getName());
		result.setToken(token);

		var employee = account.getEmployee();

		result.setAssignDate(employee.getAssignDate());
		result.setDepartmentCode(employee.getDepartment().getCode());
		result.setDepartmentName(employee.getDepartment().getName());
		result.setPositionCode(employee.getPosition().getId().getCode());
		result.setPositionName(employee.getPosition().getId().getPositionCode().getValue());
		result.setStatus(employee.getStatus());

		var permissions = employee.getPosition().getPermissions();

		result.setPermissions(permissions);

		return result;
	}

	private SignInResult buildResultForAdmin(Account account, String token) {
		var result = new SignInResult();
		result.setActivated(account.isActivated());
		result.setAuthorities(List.of(account.getRole().name()));
		result.setLoginId(account.getUsername());
		result.setName(account.getName());
		result.setToken(token);
		return result;
	}

}
