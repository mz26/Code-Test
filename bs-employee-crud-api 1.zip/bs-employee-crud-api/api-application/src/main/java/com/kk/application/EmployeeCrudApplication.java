package com.kk.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
@CrossOrigin("*")
@ComponentScan(basePackages = {"com.kk.application", "com.kk.domain", "com.kk.master", "com.kk.utils"})
public class EmployeeCrudApplication {
	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudApplication.class, args);
	}
}
