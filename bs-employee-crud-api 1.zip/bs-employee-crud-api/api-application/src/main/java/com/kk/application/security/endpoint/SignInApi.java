package com.kk.application.security.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.application.security.dto.SignInForm;
import com.kk.application.security.dto.SignInResult;
import com.kk.application.security.service.ApiSecurityService;
import com.kk.utils.response.ApiResponse;

@RestController
@RequestMapping("public")
public class SignInApi {
	
	@Autowired
	private ApiSecurityService service;

	@PostMapping("signin")
	ApiResponse<SignInResult> signIn(
			@Validated @RequestBody SignInForm form, BindingResult result) {
		return ApiResponse.success(service.signIn(form));
	}
}
