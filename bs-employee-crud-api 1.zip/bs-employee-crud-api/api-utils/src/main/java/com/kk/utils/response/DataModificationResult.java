package com.kk.utils.response;

public record DataModificationResult<ID>(
		ID id,
		String message
		) {

}
