package com.kk.master.input;

import com.kk.domain.entity.Employee.Status;

import jakarta.validation.constraints.NotNull;

public record EmployeeFormForUpdateStatus(
		@NotNull(message = "Please select status.")
		Status status,
		String remark
		) {

}
