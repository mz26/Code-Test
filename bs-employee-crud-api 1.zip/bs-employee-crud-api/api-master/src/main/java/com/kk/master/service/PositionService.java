package com.kk.master.service;

import static com.kk.utils.helpers.EntityOperationHelper.created;
import static com.kk.utils.helpers.EntityOperationHelper.getOne;
import static com.kk.utils.helpers.EntityOperationHelper.updated;

import java.util.List;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kk.domain.entity.Position;
import com.kk.domain.entity.PositionPk;
import com.kk.domain.entity.PositionPk_;
import com.kk.domain.entity.Position_;
import com.kk.domain.repo.PositionRepo;
import com.kk.master.input.PositionFormForCreate;
import com.kk.master.input.PositionFormForUpdate;
import com.kk.master.input.PositionSearch;
import com.kk.master.output.PositionInfo;
import com.kk.master.output.PositionInfoDetails;
import com.kk.utils.exceptions.ApiBusinessException;
import com.kk.utils.response.DataModificationResult;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;

@Service
@Transactional
public class PositionService {

	private static final String DOMAIN_NAME = "Position";

	@Autowired
	private PositionRepo repo;

	public DataModificationResult<String> create(PositionFormForCreate form) {

		var entity = form.entity();

		if (repo.findById(entity.getId()).isPresent()) {
			var message = "Position code %s has already been used in department with code %s."
					.formatted(form.position(), form.department());
			throw new ApiBusinessException(message);
		}

		entity = repo.save(entity);

		return created(entity.getId().getCode(), DOMAIN_NAME);
	}

	@Transactional(readOnly = true)
	public DataModificationResult<String> update(String code, PositionFormForUpdate form) {
		var id = PositionPk.parse(code);
		var entity = getOne(repo.findById(id), DOMAIN_NAME, id.getCode());

		entity.setBasicSalary(form.basicSalary());
		entity.setOtFeesPerHour(form.otPerHour());
		entity.setAnualLeaves(form.anualLeaves());

		return updated(id.getCode(), DOMAIN_NAME);
	}

	@Transactional(readOnly = true)
	public PositionInfoDetails findById(String code) {
		var id = PositionPk.parse(code);
		var entity = getOne(repo.findById(id), DOMAIN_NAME, code);
		return PositionInfoDetails.from(entity);
	}

	@Transactional(readOnly = true)
	public List<PositionInfo> search(PositionSearch search) {
		return repo.search(queryFunc(search));
	}

	private Function<CriteriaBuilder, CriteriaQuery<PositionInfo>> queryFunc(PositionSearch search) {
		return cb -> {
			var cq = cb.createQuery(PositionInfo.class);

			var root = cq.from(Position.class);
			cq.multiselect(PositionInfo.select(root));
			cq.where(search.where(cb, root));
			cq.orderBy(cb.asc(root.get(Position_.id).get(PositionPk_.departmentCode)),
					cb.asc(root.get(Position_.id).get(PositionPk_.positionCode)));
			return cq;
		};
	}
}