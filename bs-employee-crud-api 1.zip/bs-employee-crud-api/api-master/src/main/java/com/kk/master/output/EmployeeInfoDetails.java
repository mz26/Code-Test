package com.kk.master.output;

import java.time.LocalDate;

import com.kk.domain.entity.Employee;
import com.kk.domain.entity.Employee.Gender;
import com.kk.domain.entity.Employee.Status;
import com.kk.domain.entity.PositionPk.PositionCode;

public record EmployeeInfoDetails(
		String code,
		String name,
		String loginId,
		String phone,
		String email,
		LocalDate dateOfBirth,
		Gender gender,
		String departmentCode,
		String department,
		PositionCode position,
		Status status,
		LocalDate assignAt,
		LocalDate provationPassAt,
		LocalDate retiredAt,
		String remark) {
	
	public String getPositionName() {
		return position.getValue();
	}

	public static EmployeeInfoDetails from(Employee entity) {
		return new EmployeeInfoDetails(
			entity.getCode(), 
			entity.getAccount().getName(), 
			entity.getAccount().getUsername(), 
			entity.getPhone(), 
			entity.getEmail(), 
			entity.getDateOfBirth(), 
			entity.getGender(), 
			entity.getDepartment().getCode(),
			entity.getDepartment().getName(), 
			entity.getPosition().getId().getPositionCode(), 
			entity.getStatus(), 
			entity.getAssignDate(), 
			entity.getProbationPassDate(),
			entity.getRetiredDate(), 
			entity.getRemark());
	}
}
