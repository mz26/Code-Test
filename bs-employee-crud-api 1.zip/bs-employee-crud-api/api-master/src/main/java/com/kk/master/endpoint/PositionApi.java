package com.kk.master.endpoint;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.master.input.PositionFormForCreate;
import com.kk.master.input.PositionFormForUpdate;
import com.kk.master.input.PositionSearch;
import com.kk.master.output.PositionInfo;
import com.kk.master.output.PositionInfoDetails;
import com.kk.master.service.PositionService;
import com.kk.utils.response.ApiResponse;
import com.kk.utils.response.DataModificationResult;

@RestController
@RequestMapping("position")
public class PositionApi {

	@Autowired
	private PositionService service;

	@GetMapping
	ApiResponse<List<PositionInfo>> search(PositionSearch search) {
		return ApiResponse.success(service.search(search));
	}

	@PostMapping
	ApiResponse<DataModificationResult<String>> create(@Validated @RequestBody PositionFormForCreate form,
			BindingResult result) {
		return ApiResponse.success(service.create(form));
	}

	@PutMapping("{code}")
	ApiResponse<DataModificationResult<String>> update(@PathVariable String code,
			@Validated @RequestBody PositionFormForUpdate form, BindingResult result) {
		return ApiResponse.success(service.update(code, form));
	}

	@GetMapping("{code}")
	ApiResponse<PositionInfoDetails> findById(@PathVariable String code) {
		return ApiResponse.success(service.findById(code));
	}
}
