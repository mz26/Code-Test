package com.kk.master.input;

import java.util.ArrayList;

import org.springframework.util.StringUtils;

import com.kk.domain.entity.Department;
import com.kk.domain.entity.Department_;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public record DepartmentSearch(
		String department) {

	public Predicate [] where(CriteriaBuilder cb, Root<Department> root) {
		var list = new ArrayList<Predicate>();
		
		if(StringUtils.hasLength(department)) {
			var param = department.toLowerCase().concat("%");
			list.add(cb.or(
				cb.like(cb.lower(root.get(Department_.code)), param),
				cb.like(cb.lower(root.get(Department_.name)), param)
			));
		}

		return list.toArray(size -> new Predicate[size]);
	}
}
