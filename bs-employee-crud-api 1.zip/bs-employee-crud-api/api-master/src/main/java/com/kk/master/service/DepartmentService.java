package com.kk.master.service;

import static com.kk.utils.helpers.EntityOperationHelper.created;
import static com.kk.utils.helpers.EntityOperationHelper.getOne;
import static com.kk.utils.helpers.EntityOperationHelper.updated;

import java.util.List;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kk.domain.entity.Department;
import com.kk.domain.entity.Department_;
import com.kk.domain.repo.DepartmentRepo;
import com.kk.master.input.DepartmentFormForCreate;
import com.kk.master.input.DepartmentFormForUpdate;
import com.kk.master.input.DepartmentSearch;
import com.kk.master.output.DepartmentInfo;
import com.kk.master.output.DepartmentInfoDetails;
import com.kk.utils.response.DataModificationResult;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;

@Service
@Transactional
public class DepartmentService {

	private static final String DOMAIN_NAME = "Department";

	@Autowired
	private DepartmentRepo repo;

	public DataModificationResult<String> create(DepartmentFormForCreate form) {
		var entity = repo.save(form.entity());
		return created(entity.getCode(), DOMAIN_NAME);
	}

	@Transactional(readOnly = true)
	public DataModificationResult<String> update(String code, DepartmentFormForUpdate form) {
		var entity = getOne(repo.findById(code), DOMAIN_NAME, code);
		entity.setName(form.name());
		entity.setDescription(form.description());
		return updated(code, DOMAIN_NAME);
	}
	
	@Transactional(readOnly = true)
	public DepartmentInfoDetails findById(String code) {
		var entity = getOne(repo.findById(code), DOMAIN_NAME, code);
		return DepartmentInfoDetails.from(entity);
	}

	@Transactional(readOnly = true)
	public List<DepartmentInfo> search(DepartmentSearch search) {
		var queryFunc = queryFunc(search);
		return repo.search(queryFunc);
	}

	private Function<CriteriaBuilder, CriteriaQuery<DepartmentInfo>> queryFunc(DepartmentSearch search) {
		return cb -> {
			var cq = cb.createQuery(DepartmentInfo.class);
			var root = cq.from(Department.class);

			DepartmentInfo.select(cb, cq, root);
			cq.where(search.where(cb, root));

			cq.orderBy(cb.asc(root.get(Department_.code)));

			return cq;
		};
	}

}
