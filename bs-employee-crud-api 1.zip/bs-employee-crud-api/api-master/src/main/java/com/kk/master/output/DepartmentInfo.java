package com.kk.master.output;

import com.kk.domain.entity.Account_;
import com.kk.domain.entity.Department;
import com.kk.domain.entity.Department_;
import com.kk.domain.entity.Employee_;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;

public record DepartmentInfo(
		String code,
		String name,
		long employees) {

	public static void select(CriteriaBuilder cb, CriteriaQuery<DepartmentInfo> cq, Root<Department> root) {
		
		var employee = root.join(Department_.employees, JoinType.LEFT);
		var account = employee.join(Employee_.account, JoinType.LEFT);
		
		cq.multiselect(
			root.get(Department_.code),
			root.get(Department_.name),
			cb.count(employee.get(Employee_.code))
		);
		
		cq.groupBy(
			root.get(Department_.code),
			root.get(Department_.name),
			account.get(Account_.name)
		);
	}
}
